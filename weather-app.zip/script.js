const apiKey = "https://api.openweathermap.org/data/2.5/weather?units=metric&q=";
// ❗ Replace with your actual API key from openweathermap.org
const myApiKey = "YOUR_API_KEY_HERE";

const searchBtn = document.getElementById("searchBtn");
const cityInput = document.getElementById("cityInput");
const weatherCard = document.getElementById("weatherCard");
const errorMsg = document.getElementById("errorMsg");

async function fetchWeather(city) {
  try {
    const response = await fetch(`${apiKey}${city}&appid=${myApiKey}`);
    if (!response.ok) throw new Error("City not found");

    const data = await response.json();

    document.getElementById("cityName").textContent = data.name;
    document.getElementById("temperature").textContent = Math.round(data.main.temp);
    document.getElementById("humidity").textContent = data.main.humidity;
    document.getElementById("wind").textContent = data.wind.speed;
    document.getElementById("description").textContent = data.weather[0].description;
    document.getElementById("weatherIcon").src = `https://openweathermap.org/img/wn/${data.weather[0].icon}@2x.png`;

    errorMsg.textContent = "";
    weatherCard.classList.remove("hidden");
  } catch (err) {
    weatherCard.classList.add("hidden");
    errorMsg.textContent = err.message;
  }
}

searchBtn.addEventListener("click", () => {
  const city = cityInput.value.trim();
  if (city) {
    fetchWeather(city);
  } else {
    errorMsg.textContent = "Please enter a city name.";
  }
});